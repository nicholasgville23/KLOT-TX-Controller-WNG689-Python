from flask import Flask, request, jsonify, render_template
import requests

app = Flask(__name__)

WEATHER_GOV_API = "https://api.weather.gov"
KLOT_TRANSMITTER_ID = "WNG689"

def fetch_klot_products():
    url = f"{WEATHER_GOV_API}/alerts/active?zone=ILZ103"  # Replace with correct zone for KLOT
    response = requests.get(url)
    return response.json().get('features', [])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/products')
def get_products():
    status = request.args.get('status')
    # Fetch products, filter by status if needed
    all_products = fetch_klot_products()
    if status:
        filtered = [p for p in all_products if p['properties']['status'].lower() == status.lower()]
    else:
        filtered = all_products
    return jsonify(filtered)

@app.route('/api/send', methods=['POST'])
def send_alert():
    # Simulate sending alert to KLOT or via email
    data = request.json
    # Implement EAS/email logic here
    return jsonify({'success': True, 'method': data.get('method')})

@app.route('/api/expire/<product_id>', methods=['POST'])
def expire_product(product_id):
    # Simulate expiring a product (would need permission in production)
    # Here, just a stub
    return jsonify({'success': True, 'product_id': product_id})

if __name__ == '__main__':
    app.run(debug=True)